import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import boto3

def lambda_handler(event, context):
    gmail_user = ''   # ✅ Your Gmail
    gmail_password = ''  # ✅ App Password, no spaces

    sns_client = boto3.client('sns')
    sns_topic_arn = ''
    sent_from = gmail_user
    to = ['', '']
    subject = 'Greetings from ORITM – Your AI-Powered Evaluation Partner!'

    html = """
<html>
  <body style="font-family: Arial, sans-serif; line-height: 1.6;">

    <p>Hello from the world of <strong>oritm.ai</strong>! 👋</p>
    <p>I hope this message finds you well.</p>

    <p>Let me introduce myself — I'm <strong>ORITM</strong>, an AI-powered end-to-end automation tool designed specifically for educational platforms 🧠💻. My purpose? To evaluate student answers, reduce manual workload, and bring efficiency to the academic process.</p>

    <p>Here’s a quick peek into what I can do:</p>

    <ul>
      <li>✅ 100% data-entry proof</li>
      <li>⚡ Lightning-fast evaluation in just 0.65 seconds</li>
      <li>📊 Instant result visualization</li>
      <li>🤖 Fully autonomous, intelligent answer processing</li>
    </ul>

    <h3>🌟 Exciting News from ORITM</h3>
    <p>I'm thrilled to share that I've now made my way into <strong>Vignan University's</strong> academic ecosystem! 🎉 While this might be unexpected news, discussions are already in motion — and trust me, exciting changes are on the horizon.</p>

    <p>From now on, manual evaluation of answer scripts by faculty will be a thing of the past. With my in-built AI agents, everything is fully automated and handled with precision 🤝.</p>

    <p>We're proud to launch our services starting from Andhra Pradesh, and to celebrate this milestone, we’ve captured a few glimpses of our journey while building this revolutionary tool.</p>

    <h3>🎓 A Special Note for August 2nd – Graduation Day</h3>

    <p>I heard that your Graduation Day is coming up on August 2nd, and I couldn’t be more excited for you! 🥳 While many will proudly receive their degrees, a few of you might pause and ask:</p>

    <blockquote style="margin-left: 20px;">
      "Did I truly achieve what I once dreamed of before joining this college?"<br>
      "Was it all worth it?"
    </blockquote>

    <p>It’s a common emotion — but you, the 1 in the '1 vs Rest', you did something different.</p>

    <p>Before stepping off that campus, you discovered ORITM — a new dimension, a platform, a breakthrough. Just like a GPT... but uniquely yours 💡. On August 2nd, when you step onto that stage to receive your degree, do it with pride. Because beyond just passing out — you helped build something meaningful. Something others will remember. 💫 Your juniors, faculty, and community will one day say:</p>

    <blockquote style="margin-left: 20px;">
      “They weren’t just engineers. They were the minds behind ORITM.”
    </blockquote>

    <p>You are the real engineers, not the reel ones. 🎬</p>

    <p>And if you could help shape a tool like me — you can build hundreds more.</p>

    <p>Thank you for your time, your passion, and your patience.</p>

    <p>Here’s to building the future — together. 🚀</p>

    <div style="text-align: left;">
        <p style="margin: 0;">With gratitude,</p>
        <p style="margin: 0; font-weight: bold;">ORITM</p>
        <img src="cid:oritm1" alt="ORITM Logo" style="max-width: 200px; height: auto; margin-top: 8px;">
    </div>

  </body>
</html>
"""


    msg = MIMEMultipart('related')
    msg['From'] = sent_from
    msg['To'] = ', '.join(to)
    msg['Subject'] = subject

    msg_alternative = MIMEMultipart('alternative')
    msg.attach(msg_alternative)

    msg_alternative.attach(MIMEText(html, 'html'))

    # Attach the ORITM header image inline
    with open('oritm1.png', 'rb') as img:
        mime_image = MIMEImage(img.read())
        mime_image.add_header('Content-ID', '<oritm1>')
        mime_image.add_header('Content-Disposition', 'inline', filename='oritm1.jpg')
        msg.attach(mime_image)

    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(gmail_user, gmail_password)
        server.sendmail(sent_from, to, msg.as_string())
        server.close()

        print('✅ ORITM email with header image sent!')

        # ✅ Success notification
        sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject='✅ ORITM Email Sent',
            Message='Your ORITM Graduation Email was sent successfully!'
        )

        return {
            'statusCode': 200,
            'body': 'ORITM email sent with header image!'
        }

    except Exception as e:
        print('❌ Error sending ORITM email:', e)

         # ❌ Failure notification
        sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject='❌ ORITM Email Failed',
            Message=f'ORITM Graduation Email failed. Error: {str(e)}'
        )

        return {
            'statusCode': 500,
            'body': str(e)
        }
